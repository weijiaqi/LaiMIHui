package com.coldraincn.laimihui.entity;

/**
 * Created by hd on 2017/9/12.
 */

public class Address {
}
