package com.coldraincn.laimihui.entity;

/**
 * Created by hd on 2017/9/9.
 */

public class BindPhone {

    /**
     * status : OK
     * data : 绑定成功
     */

    private String status;
    private String data;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}
