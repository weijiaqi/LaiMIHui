package com.coldraincn.laimihui.Alipay;

/**
 * Created by hd on 2017/9/10.
 */

public class WeixinSetting {

    // 商户PID
    public static final String APP_ID = "2088221838328263";
    // 微信支付商户号
    public static final String partnerid = "2088221838328263";
}
