package com.coldraincn.laimihui.view;

/**
 * Created by hd on 2017/9/7.
 */

public interface BaseView {
}
