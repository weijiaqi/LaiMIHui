package com.coldraincn.laimihui.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by hd on 2017/9/8.
 */

public class NineGridTestModel implements Serializable {
    private static final long serialVersionUID = 2189052605715370758L;

    public List<String> urlList = new ArrayList<>();

    public boolean isShowAll = false;
}
