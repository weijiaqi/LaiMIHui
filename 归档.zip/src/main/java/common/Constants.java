package common;

import com.tencent.mm.opensdk.openapi.IWXAPI;

/**
 * Created by hd on 2017/9/8.
 */

public class Constants {
    public static final String APP_ID = "wx3bb6d108dec83903";
    public static final String AppSecret = "815b6769d10ec813466d834952061137";


    public static class ShowMsgActivity {
        public static final String STitle = "showmsg_title";
        public static final String SMessage = "showmsg_message";
        public static final String BAThumbData = "showmsg_thumb_data";
    }
}
